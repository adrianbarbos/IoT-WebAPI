<?php
/**
 * Database config variables
 */


/*
 * Google Cloud Messaging API Key
 */
define("GOOGLE_API_KEY", "AIzaSyDP0iiV7iGbugKKZehHlsVkdB3Okl_KOwQ"); // Place your Google API Key
                          
?>