<?php
//Database config
define('DB_USER', "b299005341c5ab"); // db user
define('DB_PASS', "baa639b9"); // db password (mention your db password here)
define('DB_NAME', "ad_0b0fb6028206c09"); // database name
define('DB_HOST', "us-cdbr-iron-east-02.cleardb.net"); // db server

//MVD nottification config
define('MVD_REG_ID', 'dfjksdjkjk5jksjk45jkj54j43k3k'); // MVD GCM ID

//Api config
define('API_KEY', "API_KEY");
define('API_SECRET', "cyAa6pnNvAVtSZyNegGT");
define('API_METHOD_KEY', "METHOD");
define('API_METHOD_VALUE', "storeData");